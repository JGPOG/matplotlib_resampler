# Matplotlib Dynamic Downsampler
### High Performance Time-Series Visualization

A python package for universal **data downsampling and interactive visualization** 
using Matplotlib and tsodwnsampler.

`matplot_enhanced` improves scalability of `Matplotlib` for visualizing massive time-series
datasets. The library *dynamically* **aggregates time-series data respective to the current
graph view**, ensuring fast, responsive updates during panning or zooming. 

This aggregation functionality is achieved by utilizing highly optimized data point selection
algorithms from **tsdownsample**. Our default data aggregation method is MinMaxLTTB (defaulting
to 5,000 points per view), which guarantees maximum visual fidelity and preserves narrow data spikes.

This works with more than 1 plot and can visualize over 200,000,000 data points.

## Features

- **Convenient and "Plug & Play"**: Just pass your existing plt object to our enhance(plt, n_out=num_example) 
    method. Preserves all original Matplotlib styling, colors, labels and figure configurations.
- **No Backend Servers Required**: Requires zero web servers, Dash apps, or Jupyter widget overhead.
    Runs entirely via Matplotlib's native event backend.
- **Efficient visualization of large datasets**: Dynamic zooming in and out while keeping high fidelity
    based on user's point preference.

## Installation

Clone the repository:
git clone https:....

Install the package:
pip install -e .

The package automatically installs its dependencies:
- NumPy
- Pandas
- Matplotlib
- tsdownsample
 
Or to install the dependencies manually:
pip install numpy pandas matplotlib tsdownsample

## Usage
Add dynamic aggregation to your figure with zero code overhead.

```python 
import numpy as np
import matplotlib.pyplot as plt
import matplot_enhanced

# Generate data (50M points)
num_points = 50_000_000
x = np.linspace(0, 6 * np.pi, num_points)
y = np.sin(x)

# Define noise levels and number of spikes
noise_levels = [0.1, 0.3, 0.5, 0.7]
num_spikes = 10
spike_magnitude = 5

# Create a figure and a set of subplots
fig, axes = plt.subplots(4, 1, figsize=(10, 8), sharex=True)
fig.suptitle('Sine Waves with Varying Noise and Spikes', fontsize=16)

for i, ax in enumerate(axes):
    noise_level = noise_levels[i]
    
    # Add Gaussian noise
    noisy_y = y + np.random.normal(0, noise_level, num_points)
    # Add random spikes
    spike_indices = np.random.choice(num_points, num_spikes, replace=False)
    spiky_y = noisy_y.copy()
    # Randomly make spikes positive or negative
    spike_directions = np.random.choice([-1, 1], num_spikes)
    spiky_y[spike_indices] += spike_directions * spike_magnitude
    # Plot the sine wave
    ax.plot(x, spiky_y, label=f'Noise Level: {noise_level}')
    ax.set_ylabel('Amplitude')
    ax.legend(loc='upper right')
    ax.grid(True)

# Set common labels
plt.xlabel('X-axis')
plt.tight_layout(rect=[0, 0.03, 1, 0.95])

# Wrap the figure to enable dynamic downsampling (default resolution is 5,000)
matplot_enhanced.enhance(plt, n_out=5000)

plt.show()
```

`In usage demo, 200,000,000 data points across 4 subplots (50M each) are visualized!`

## Matplotlib Standalone vs Matplotlib + Enhancer
matplot_enhance() acts as an invisible wrapper around standard Matplotlib figures.
It adds visualization scalability to line charts by dynamically aggregating the data
relative to the current front-end view bounds (xlim).
- **Standard Matplotlib** attempts to render every single data point, which can freeze
    your UI or crash when dealing with millions of rows
- **matplotlib_enhancer** intercepts these points *before* rendering and only plots
    a mathematically representative downsampled version. When you zoom in, it
    automatically recalculates and reveals the high resolution details for that window.

## Important Considerations & Tips

- **Sorting Requirement**: The underlying tsdownsample Rust engine requires your X-axis data
    to be monotonic/sorted and free of NaN values. This wrapper automatically cleans and sorts the
    provided arrays on initialization to guarantee stability.
- **Aliasing and Signal Spikes**: MinMaxLTTB ensures extreme peaks and troughs in raw data are never
    accidentally skipped when rendering a zoomed out view.
- **Exporting/Saving**: Because the plot dynamically updates based on current view, saving the plot
    directly to PDF/PNG (e.g., plt.savefig()) will save the *currently downsampled* state of the view
    you are looking at.
